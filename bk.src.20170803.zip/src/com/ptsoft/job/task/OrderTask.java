package com.ptsoft.job.task;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.ptsoft.pts.business.service.OrderService;

@Component
public class OrderTask 
{

	@Autowired
	private OrderService orderService;
	
	//@Scheduled(cron = "0 0 0 0/6 * *")
	//@Scheduled(cron = "0 0/2 * * * ?")
	@Scheduled(cron = "30 19-22 11 * * *")
	public void syncPurchase()
	{
		System.out.println(123456566);
		/*this.orderService.syncPurchase(null);
		this.orderService.syncSalesOrder(null);
		this.orderService.updateSalesNo(null);*/
	}
	
}
