package com.ptsoft.common.util;

public class EhcacheUtil
{

}
