package com.ptsoft.pts.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 连接SQL server Util
 * @author jqi.can
 * @date 2016-07-14
 */
public class DBUtil 
{
	private static final Logger logger = LoggerFactory.getLogger(DBUtil.class);
	
	public static Connection getConn()
	{
		String driver = "com.microsoft.jdbc.sqlserver.SQLServerDriver";
		
		/*String url = "jdbc:microsoft:sqlserver://10.1.10.92:1433;DatabaseName=wf";
		String username = "wfpts";
		String password = "wfpts123456";*/
		
		String url = "jdbc:microsoft:sqlserver://192.168.1.3:1433;DatabaseName=wfpts";
		String username = "sa";
		String password = "2wsx3edc";
		
		Connection conn = null;
		try 
		{
			Class.forName(driver);
			conn = DriverManager.getConnection(url, username, password);
		}
		catch (Exception e) 
		{
			logger.error("--getConn--" +e.toString());
		}
		return conn;
		
	}
	
	public static int insert(String info)
	{
		int result = 0;
		String sql = "Insert Into TB_PTS_PRODUCT(qrCode, productCode, packageRule, packageLevel, createDate, sapNo, name, orderNo) " +
				"Values(?, ?, ?, ?, ?, ?, ?, ?)";
		String[] detail = info.split(",");
		
		Connection conn = getConn();
		PreparedStatement pstmt;
		
		try 
		{
			//二维码 产品编码 包装规则 包装层级 创建日期 SAP号 产品名称 订单号
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, detail[0]);
			pstmt.setString(2, detail[1]);
			pstmt.setString(3, detail[2]);
			pstmt.setInt(4, Integer.parseInt(detail[3]));
			pstmt.setString(5, detail[4]);
			pstmt.setString(6, detail[5]);
			pstmt.setString(7, detail[6]);
			pstmt.setString(8, detail[7]);
			
			result = pstmt.executeUpdate();
			pstmt.close();
			conn.close();
		}
		catch (Exception e) 
		{
			logger.error("--insert--" + e.toString());
		}
		return result;
	}
	
	public static String select(int id)
	{
		String result = "";
		String sql = "Select qrcode From TB_PTS_PRODUCT Where id = ?";
		Connection conn = getConn();
		PreparedStatement pstmt;
		try 
		{
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, id);
			ResultSet rst = pstmt.executeQuery();
			while (rst.next()) 
			{
				result = rst.getString("qrcode");
			}
			pstmt.close();
			conn.close();
		} catch (Exception e) 
		{
			logger.error("--select--" + e.toString());
		}
		return result;
	}
	
	public static void main(String[] args)
	{
		//System.out.println(select(6084));
		System.out.println(queryIsExist("http://pts.weifu.com.cn/PTS/Qr.html?Y2PnbH9tHXX3Obebrc2f2D1HA6e2YHTlTjACBwXE/w0eYaI9n7+9A/p8kUkxQyCD"));
	}

	public static int queryIsExist(String qrcode) {
		int result = 0;
		String sql = "Select id From TB_PTS_PRODUCT Where qrcode = ?";
		Connection conn = getConn();
		PreparedStatement pstmt;
		try 
		{
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, qrcode);
			ResultSet rst = pstmt.executeQuery();
			while (rst.next()) 
			{
				result = rst.getInt("id");
			}
			pstmt.close();
			conn.close();
		} catch (Exception e) 
		{
			logger.error("--select--" + e.toString());
		}
		return result;
	}
}
