package com.ptsoft.controller.api;

import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.ptsoft.common.util.ResponseUtils;
import com.ptsoft.pts.account.model.vo.SysUser;
import com.ptsoft.pts.account.service.UserService;
import com.ptsoft.pts.basic.service.TraceService;
import com.ptsoft.pts.business.model.vo.SalesOrder;
import com.ptsoft.pts.business.service.SaleOrderService;

@Controller("ApiInoutController")
@RequestMapping("/api/inout/*")
public class InoutController {
	
	Logger logger = Logger.getLogger(InoutController.class);
	
	@Autowired
	private TraceService traceService;
	@Autowired
	private UserService userService;
	@Autowired
	private SaleOrderService saleOrderService;
	
	/**
	 * 入库
	 * @author zumin.yang
	 * @date 2016-03-15
	 * @param qrcodes 二维码
	 * @param deviceNo 设备号 
	 */
	@RequestMapping(value="in", method=RequestMethod.POST)
	public void in(HttpServletRequest request, HttpServletResponse response, String qrcodes, String deviceNo)
	{
		response.setHeader("Access-Control-Allow-Origin", "*");
		String username = request.getParameter("username");
		String token = request.getParameter("token");
		SysUser user = userService.findByNameAndToken(username, token);
		logger.info("***********入库*******");
		logger.info("user="+user.getLgnNm()+"  qrcodes="+qrcodes);
		HashMap<String, Object> map = traceService.saveIn(user, qrcodes, deviceNo);
		
		ResponseUtils.renderJson(response, map);
	}
	
	/**
	 * 出库
	 * @author zumin.yang
	 * @date 2016-03-16
	 * @param orderNo 出库单号
	 * @param qrcodes 出库扫描二维码
	 * @param deviceNo 设备号
	 */
	@RequestMapping(value="out", method=RequestMethod.POST)
	public void out(HttpServletRequest request, HttpServletResponse response, String orderNo, String qrcodes, String deviceNo)
	{
		response.setHeader("Access-Control-Allow-Origin", "*");
		
		String username = request.getParameter("username");
		String token = request.getParameter("token");
		SysUser user = userService.findByNameAndToken(username, token);
		logger.info("***********出库*******");
		logger.info("user="+user.getLgnNm()+" orderNo="+orderNo+" qrcodes="+qrcodes);
		HashMap<String, Object> map =null;
		try
		{
		   map = traceService.saveOut(user, orderNo, qrcodes, deviceNo);
		}
		catch(Exception ex)
		{
			logger.info("***********出库 error*******"+ex.getMessage());
			map=new HashMap<String, Object>();
			map.put("code", 0);
			map.put("msg", "出库失败，"+ex.getMessage());
			map.put("msg_en", "Outstock failure. "+ex.getMessage());
			map.put("msg_code", "3001");
		}
		
		ResponseUtils.renderJson(response, map);
	}
	
	/**
	 * 退货（不换二维码）洗白
	 * @author zumin.yang
	 * @date 2016-03-16
	 * @param qrcode 二维码
	 */
	@RequestMapping(value="return", method=RequestMethod.POST)
	public void returned(HttpServletRequest request, HttpServletResponse response, String qrcode)
	{
		response.setHeader("Access-Control-Allow-Origin", "*");

		String username = request.getParameter("username");
		String token = request.getParameter("token");
		SysUser user = userService.findByNameAndToken(username, token);
		
		logger.info("***********退货*******");
		logger.info("user="+user.getLgnNm()+" qrcode="+qrcode);
		
		HashMap<String, Object> map = traceService.returned(qrcode, user);
		ResponseUtils.renderJson(response, map);
	}
	
	/**
	 * 作废二维码
	 * @author zumin.yang
	 * @date 2016-03-16
	 * @param qrcode 二维码
	 */
	@RequestMapping(value="void", method=RequestMethod.POST)
	public void toVoid(HttpServletRequest request, HttpServletResponse response, String qrcode)
	{
		response.setHeader("Access-Control-Allow-Origin", "*");

		String username = request.getParameter("username");
		String token = request.getParameter("token");
		SysUser user = userService.findByNameAndToken(username, token);
		logger.info("***********作废*******");
		logger.info("user="+user.getLgnNm()+" qrcode="+qrcode);
		HashMap<String, Object> map = traceService.toVoid(qrcode, user);
		ResponseUtils.renderJson(response, map);
	}
	
	/**
	 * 获取出库单明细
	 * @author jqi.can
	 * @date 2016-3-24下午09:21:02
	 * @param orderNo 出库单号
	 */
	@RequestMapping(value="saleOrderDetail", method = RequestMethod.POST)
	public void saleOrderDetail(HttpServletRequest request, HttpServletResponse response, String orderNo)
	{
		response.setHeader("Access-Control-Allow-Origin", "*");

		String username = request.getParameter("username");
		String token = request.getParameter("token");
		SysUser user = userService.findByNameAndToken(username, token);
		HashMap<String, Object> map = new HashMap<String, Object>();
		SalesOrder salesOrder = this.saleOrderService.getByKingId(orderNo);
		if(user == null)
		{
			map.put("code", "0");
			map.put("msg", "获取出库单明细失败！");
		}
		else
		{
			if(salesOrder == null)
			{
				map.put("detail", null);
				map.put("isRestrict", 1);
				map.put("code", "1");
				map.put("msg", "出库单不存在");
			}
			else
			{
				map.put("detail", this.saleOrderService.getDetailByOrderId(String.valueOf(salesOrder.getId())));
				map.put("isRestrict", salesOrder.getIsRestrict());
				map.put("code", "1");
				map.put("msg", "获取出库单明细成功！");
			}
		}
		ResponseUtils.renderJson(response, map);
	}
}
