package com.ptsoft.pts.util;

import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpException;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.httpclient.params.HttpMethodParams;

public class HttpUtil 
{
	public static String executeGet(String url) throws Exception 
	{
		HttpClient client = new HttpClient();
		String sb = "";

		InputStream ins = null;
		// Create a method instance.
		GetMethod method = new GetMethod(url);
		try {
			// Execute the method.
			int statusCode = client.executeMethod(method);
			// System.out.println("======http exec get status code=========" +
			// statusCode);
			if (statusCode == HttpStatus.SC_OK) 
			{
				// ins = method.getResponseBodyAsStream();
				byte[] b = method.getResponseBody();
				sb = new String(b, "UTF-8");

				/**
				 * byte[] b = new byte[1024]; int r_len = 0; while ((r_len =
				 * ins.read(b)) > 0) { sb.append(new String(b, 0, r_len,
				 * method.getResponseCharSet())); }
				 */
			} 
			else 
			{
				System.err.println("Response Code: " + statusCode);
			}
		} 
		catch (HttpException e) 
		{
			System.err.println("Fatal protocol violation: " + e.getMessage());
		} 
		catch (IOException e) 
		{
			System.err.println("Fatal transport error: " + e.getMessage());
		} 
		finally 
		{
			method.releaseConnection();
			if (ins != null) 
			{
				ins.close();
			}
		}
		return sb;

	}

	public static String executePost(String url, String info, String createtimes) 
	{
		HttpClient client = new HttpClient();
		String msg = "";
		try
		{
			PostMethod method = new PostMethod(url);
			
			method.getParams().setParameter(HttpMethodParams.HTTP_CONTENT_CHARSET, "UTF-8");
			
			if(null != info && !"".equals(info))
			{
				method.setParameter("qrcodes", info);
			}
			if(null != createtimes && !"".equals(createtimes))
			{
				method.setParameter("createtimes", createtimes);
			}
			
			int statusCode = client.executeMethod(method);
			if (statusCode == HttpStatus.SC_OK) 
			{
				byte[] b = method.getResponseBody();
				msg = new String(b, "UTF-8");
			} 
			else 
			{
				System.err.println("Response Code: " + statusCode);
			}

		} 
		catch (MalformedURLException ex) 
		{
			ex.printStackTrace();
		}
		catch (IOException ex)
		{
			ex.printStackTrace();
		}
		
		return msg;
	}
	
}
